require 'flexmock/rspec'
require File.expand_path(File.dirname(__FILE__) + '/spec_helper')

describe RightImageTools::MCI do

  before :each do 
    @mci = RightImageTools::MCI.new

    @mock_mci_name = "Mock_RightImage_Ubuntu_10.04_x64_v5.7" 
    @mock_ami = "ami-2ehahaha"

    @mock_mci = flexmock(MultiCloudImage, 
      :is_head_version => true, 
      :name => @mock_mci_name,
      :rs_id => "10000", 
      :version=>0, 
      :href=>"https://my.rightscale.com/api/acct/99999/multi_cloud_images/10000")
    @mock_mci.should_receive(:find_and_flatten_settings)

    @mock_mci_setting1 = flexmock(MultiCloudImageCloudSettingInternal,
      :href=>"https://my.rightscale.com/api/acct/99999/multi_cloud_image_cloud_settings/20000", 
      :aws_instance_type =>"m1.small",
      :image_name => @mock_mci_name,
      :image_href => "https://my.rightscale.com/api/acct/0/ec2_images/#{@mock_ami}?cloud_id=5",
      :cloud_id=>5,
      :cloud=>"AWS AP-Tokyo")
    @mock_mci.should_receive(:multi_cloud_image_cloud_settings).and_return([@mock_mci_setting1, @mock_mci_setting1])

    @mock_mci_i = flexmock(MultiCloudImageInternal, 
      :is_head_version => @mock_mci.is_head_version, 
      :name=>@mock_mci.name,
      :rs_id => @mock_mci.rs_id, 
      :version=>@mock_mci.version, 
      :href=>@mock_mci.href,
      :multi_cloud_image_cloud_settings=>[@mock_mci_setting1, @mock_mci_setting1])
  end

#  it "finds a MCI for gateway cloud (cloudstack)" do
#    pending "TODO"
#  end
#  it "creates a MCI for gateway cloud (cloudstack)" do
#    pending "TODO"
#  end
#  it "associates an image for a gateway cloud (cloudstack)" do 
#    pending "TODO"
#  end
#  it "replaces an image association for a gateway cloud (cloudstack)" do 
#    pending "TODO"
#  end
#
  it "finds a MCI for EC2 cloud" do
    flexmock(MultiCloudImage).should_receive(:find_all).and_return([@mock_mci])
    flexmock(MultiCloudImageInternal).should_receive(:find).with(10000).and_return(@mock_mci_i)
  
    @mci.find_mci(6, @mock_mci_name).rs_id.should == "10000"
  end
  it "creates a MCI for EC2 mock cloud" do
    flexmock(MultiCloudImageInternal).should_receive(:create).with(
      :name=>@mock_mci_name,
      :description => "blah"
    ).and_return(flexmock(MultiCloudImageInternal))
    flexmock(MultiCloudImage).should_receive(:find).and_return(@mock_mci)
    @mci.create_mci(6, @mock_mci_name, "blah")
  end

  it "associates an image to an EC2 cloud" do 
    flexmock(MultiCloudImage).should_receive(:find_all).and_return([@mock_mci])
    flexmock(MultiCloudImageInternal).should_receive(:find).with(10000).and_return(@mock_mci_i)
    flexmock(Tag).should_receive(:set).and_return(flexmock(Tag, :code=>"204"))
    flexmock(MultiCloudImageCloudSettingInternal).should_receive(:create)

    @mci.add_image_to_mci(
      :cloud_id=>6,
      :name=>@mock_mci_name,
      :image_id=>"ami-b1ahb1ah")
  end

  it "replaces an image association for an EC2 cloud" do 
    flexmock(MultiCloudImage).should_receive(:find_all).and_return([@mock_mci])
    flexmock(MultiCloudImageInternal).should_receive(:find).with(10000).and_return(@mock_mci_i)
    flexmock(Tag).should_receive(:set).and_return(flexmock(Tag, :code=>"204"))
    flexmock(MultiCloudImageCloudSettingInternal).should_receive(:destroy).and_return(flexmock("Response",:code=>"200"))
    flexmock(MultiCloudImageCloudSettingInternal).should_receive(:create)

    @mci.add_image_to_mci(
      :cloud_id=>5,
      :name=>@mock_mci_name,
      :image_id=>"ami-b1ahb1ah")
  end

end
