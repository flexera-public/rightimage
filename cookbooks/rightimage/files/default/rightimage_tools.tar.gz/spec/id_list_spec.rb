require 'flexmock/rspec'
require File.expand_path(File.dirname(__FILE__) + '/spec_helper')

describe RightImage::IdList do
  before(:each) do
    mock_logger = flexmock('Logger')
    mock_logger.should_receive(:info)

    @id_list = RightImage::IdList.new(mock_logger)
    @id_list.clear
    #{"ami-96f200ff":{"storage_type":"EBS"},"ami-8af200e3":{}}
    #{"ami-08f30161":{"storage_type":"EBS"},"ami-fcf20095":{"storage_type":"EBS"}}
    @id_list.add("ami-8af200e3\n")

    @id_list = RightImage::IdList.new(mock_logger)
    @id_list.add("ami-foo\n", "EBS")

    @images = @id_list.to_hash
  end

  it "should contain two images" do
    @images.size.should == 2
  end

  it "should contain one EBS images" do
    ebs_images = @images.select { |k, v| v["storage_type"] && v["storage_type"] == "EBS" }
    ebs_images.size.should == 1
  end

end
