# rightimage_tools

RightImage tools is a collection of miscellaneous scripts and libraries useful
for managing certain aspects of RightImage creation.  Most scripts should have
a help screen.

## Usage
```
bundle install --without private development
bundle exec bin/update_s3_index rightscale-cloudstack-dev
bundle exec bin/mci_add --cloud-id 6 --image-id aws-abcdef01 --name RightImage_CentOS_5.6_x64_v5.8 --rightlink-version 5.8.8
```

## Use in rightimage creator
When exporting to rightimage_creator, please bundle exec rake spec under both
ruby 1.8 and ruby 1.9, then please use the rake task:
```
bundle exec rake tarball
cp rightimage_tools.tar.gz <PATH/TO/cookbooks/rightimage/files/default>
```

## Copyright

Copyright (c) 2012 RightScale, Inc. See LICENSE.txt for further details.

Maintained by the RightScale Ivory Team
