(function () {
  'use strict';

  /* Function to fetch image name parameter. */
  (function ($) {
    $.QueryString = (function (a) {
      if (a === "") {
        return {};
      }
      var b = {}, i;
      for (i = 0; i < a.length; i++) {
        var p = a[i].split('=');
        if (p.length === 2) {
          b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
      }
      return b;
    }(window.location.search.substr(1).split('&')));
  }(jQuery));
  /* End fetch image name parameter. */

  /* Construct header. */
  // Slice up the "image" arg to get the image's name (string after the last backslash).
  // And the report path (the image's path with a '.js' extnesion).
  var image_path = $.QueryString['image'];
  var image_name = image_path.split('/').slice(-1)[0];
  var report_path = image_path.replace(/\.(vmdk|vhd|tar|qcow2|raw|tgz)/,".js").replace(/\.(gz|bz2|ova)/,"")
  // Get bucket name from beginning of base URL.
  var bucket = window.location.hostname.split('.')[0];
  var base_bucket = (bucket.indexOf('rightimage-base') !== -1);

  // Pick disclaimer depending on if dev bucket.
  var disclaimer = '';
  if (bucket.match('-dev$')) {
    disclaimer = 'The following ';
    disclaimer += (base_bucket ? 'Base Image' : 'RightImage');
    disclaimer += ' is currently in RightScale development and testing. It is not supported by RightScale. For ';
    disclaimer += (base_bucket ? 'Base Images' : 'RightImages');
    disclaimer += ' that RightScale supports, please see our <a href="http://' + bucket + '.s3.amazonaws.com/index.html">production images</a>.';
  } else {
    disclaimer = 'The following ';
    disclaimer += (base_bucket ? 'Base Image' : 'RightImage');
    disclaimer += ' is tested and supported by RightScale for general use. For further information regarding use of this image with RightScale, please contact your RightScale account manager or sign up for an account at <a href="http://www.rightscale.com">www.rightscale.com</a>.';
  }

  // Put pieces together.
  $('div.bucket').append(
    // Image name.
    $(document.createElement('a')).attr('href', image_path).text(image_name)
  ).append(
    "<br/><br/>"
  ).append(
    // Bucket name.
    $(document.createElement('a')).attr('href', 'http://' + bucket + '.s3.amazonaws.com/index.html').text(bucket)
  ).append(
    "<br/><br/>"
  ).append(
    // Disclaimer.
    $(document.createElement('div')).addClass('disclaimer code common').append(disclaimer)
  ).append(
    '<br/>'
  );
  /* End construct header. */

  // Using ajax instead of getJSON in order to have failure callback.
  $.ajax({
    url: report_path,
    dataType: 'json',

    // Retrieve JSON and create DOM in loopback.
    success: function (report) {

      // Pretty-print and order JSON fields.
      var order = [ ['lsb', 'OS'], ['virtualization', 'Virtualization'], ['cloud', 'Cloud'], ['kernel', 'Kernel'], ['modules', 'Modules'], ['rightscale-mirror', 'RightScale Repos'], ['image', 'Build'], ['packages', 'Packages'] ];

      // Definition list skeleteon.
      $('body').append(
        $(document.createElement('dl')).attr('id', 'report')
      );

      // Global packages list to accomodate reordering.
      var packs = [];

      // Each content section defined by order.
      order.forEach(function (field) {

        // Filter out fields that don't apply to base images.
        if ( ! report.hasOwnProperty(field[0]) ) { return; };

        // Add section header
        $('dl#report').append(
          $(document.createElement('dt')).addClass('collapser').text(field[1]).append(
            // Add arrow to match default uncollapsed.
            $(document.createElement('span')).addClass('arrow').addClass('down')
          )
        );

        if (field[0] === 'packages') {
          // Set arrow to match default collapsed.
          $('dt:last span').toggleClass("down right");

          // Add sorting arrow before package list.
          // Add packages dd.dl skeleteon.
          $('dt:last').after(
            $(document.createElement('dd')).addClass('collapsible').attr('id', 'packages').append(
            $(document.createElement('span')).addClass('sort_arrow').text("▲").after(
              $(document.createElement('dl'))
          )));

          // Put packages in array.
          var pack;
          for (pack in report['packages']) {
            if (report['packages'].hasOwnProperty(pack)) {
              packs.push(pack);
            }
          }

          // Sort function to account for capitals in keys.
          packs.sort(function (a, b) {
            return a.toUpperCase().localeCompare(b.toUpperCase());
          });

          // Iterate packages into skeleton using sorted keys.
          packs.map(function (pack) {
            $('dl:last').append(
              $(document.createElement('dt')).addClass('ib').text(pack).after(
              $(document.createElement('dd')).addClass('value').text(report['packages'][pack])
            ));
          });

        } else {
          // Add dd.dl skeleton.
          $('dt:last').after(
            $(document.createElement('dd')).addClass('collapsible').append(
              $(document.createElement('dl'))
          ));
          // Iterate items into skeleton.
          for (var key in report[field[0]]) {
            $('dl:last').append(
              $(document.createElement('dt')).addClass('ib').text(key).after(
              $(document.createElement('dd')).addClass('value').text(report[field[0]][key])
            ));
          };
        };
      });


      // Zebra stripe each section's contents.
      $('dd.collapsible>dl>dd:even').addClass('even');


      // Collapse/uncollapse lists by clicking on header.
      // Rotate arrows to match
      $('dt.collapser').click(function () {
        // Uncollapse.
        if ($(this).next('.collapsible').is(":hidden")) {
          $(this).next('.collapsible').slideDown('slow');
          $(this.children[0]).toggleClass("right down");
        // Collapse.
        } else {
          $(this).next('.collapsible').slideUp('slow');
          $(this.children[0]).toggleClass("down right");
        };
      });


      // Reorder packages by clicking on list.
      $('dd#packages').click(function () {
        // Reverse package sort.
        packs.reverse();

        // Flip ASCII arrow when list is sorted.
        if ($(this.children[0]).text() === "▲") {
          $(this.children[0]).text('▼')
        } else {
          $(this.children[0]).text('▲')
        };

        // Create new definition list.
        var reorder = $(document.createElement('dl')); 
        // Add packages packages to skeleton using sorted keys.
        packs.map(function (pack) {
          reorder.append(
            $(document.createElement('dt')).addClass('ib').text(pack).after(
            $(document.createElement('dd')).addClass('value').text(report['packages'][pack])
          ));
        });

        // Replace with reordered definition list.
        $(this.children[1]).replaceWith(reorder);

        // Re-zebra stripe entire list.
        // Otherwise package list gets an off-by-one.
        $('dd.collapsible>dl>dd:even').addClass('even');
      });
    },
    // In case the report cannot be retrieved.
    error: function (report) {
      $('body').append(
        $(document.createElement('div')).addClass('common').append(
          $(document.createElement('p')).text('The report you have pointed to does not exist.')
      ));
    }
  });
}());