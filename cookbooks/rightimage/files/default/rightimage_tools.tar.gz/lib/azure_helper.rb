module AzureHelper
    RS_LINUX_ACCOUNTS = %w(
    rightscalewestus
    rightscaleeastus
    rightscaleeastasia
    rightscalesoutheastasia
    rightscalenortheurope
    rightscalewesteurope
  )
  RS_WINDOWS_ACCOUNTS = %w(
    rightscalewestuswin
    rightscaleeastuswin
    rightscaleeastasiawin
    rightscaleseasiawin
    rightscalenortheuropewin
    rightscalewesteuropewin
  )
  AZURE_LINUX_LOCATIONS = {
    'rightscalewesteurope' => 'West Europe',
    'rightscalesoutheastasia' => 'Southeast Asia',
    'rightscaleeastasia' => 'East Asia',
    'rightscalenortheurope' => 'North Europe',
    'rightscalewestus' => 'West US',
    'rightscaleeastus' => 'East US'
  }
#  AZURE_WINDOWS_LOCATIONS = {
#    'westeuropewin' => 'West Europe',
#    'seasiawin' => 'Southeast Asia',
#    'eastasiawin' => 'East Asia',
#    'northeuropewin' => 'North Europe',
#    'westuswin' => 'West US',
#    'eastuswin' => 'East US'
#  }
  def api_dump(api, method_name, *args)
    result = api.__send__(method_name, *args)
  ensure
    puts "--- #{method_name} ---"  
    if api.request
      puts "verb:         #{api.request.verb}"
      puts "path:         #{api.request.path.inspect}"
      puts "req headers:  #{api.request.headers.inspect}"
      puts "req body:     #{api.request.body.inspect}"
      puts " "
      if api.response
        puts "resp code:    #{api.response.code.inspect}"
        puts "resp headers: #{api.response.headers.inspect}"
        puts "resp body:    #{api.response.body.inspect}"
        puts " "
        pp result
      end
      puts "==========================================================================="
    end
  end

  def lookup_password(account)
    credsfile = "~/.azurecreds.yml"
    creds_msg = <<-EOF
    Please set up a #{credsfile} file in the following format:
    <service account name1>: <shared key2>
    <service account name1>: <shared key2>
    EOF
    begin
      creds = YAML.load_file(File.expand_path(credsfile))
    rescue
      puts creds_msg
      exit 1
    end
    password = creds[account]
    unless password
      puts "Can not find creds for account #{account} in file"
      puts creds_msg
      exit 1
    end
    password
  end

  def parse_url(url)
    uri = URI.parse(url)
    path = uri.path.reverse.chomp("/").reverse
    (container, blob) = path.split("/",2)
    account = uri.host.split(".").first
#    puts "ACCOUNT: #{account}"
#    puts "CONTAINER: #{container}"
#    puts "BLOB NAME: #{blob}"

    password = lookup_password(account)
    endpoint = "https://#{account}.blob.core.windows.net"
    return [account,password,endpoint,container,blob]
  end
end
