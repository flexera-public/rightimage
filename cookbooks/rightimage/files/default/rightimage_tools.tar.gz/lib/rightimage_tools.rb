module RightImageTools
  VERSION = File.read(File.join(File.dirname(__FILE__), "..", "VERSION")).chomp
end

require File.join(File.dirname(__FILE__), 'mci')
require File.join(File.dirname(__FILE__), 'id_list')
# command line tool 
#require File.join(File.dirname(__FILE__), 's3_html_indexer')
