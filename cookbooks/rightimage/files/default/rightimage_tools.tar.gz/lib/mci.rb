require 'rubygems'
require 'logger'
require 'rest_connection'

module RightImageTools
  class MCI

    def initialize(options = {})
      @options = options
      @logger = (@options.key?(:logger)) ? @options[:logger] : Logger.new(STDOUT)
      @api_url = Tag.connection.settings[:api_url]
    end

    def default_description(mci_name, is_ec2 = false, opts = {})
      # 32-Bit Image description
      #   OsName NN.NN Hypervisor with 32-bit architecture (i386)
      # 64-Bit image description
      #   OsName NN.NN Hypervisor with 64-bit architecture (x64)

      os = opts[:os]
      os_version = opts[:os_version]
      if os.to_s.empty?
        os = (mci_name =~ /(centos|ubuntu|windows|rhel)/i) ? $1 : ""
        unless os.to_s.empty?
          os_version = (mci_name =~ /#{os}[\s_](\d+\.\d+)/) ? $1 : ""
        end
      end
      os_arch = opts[:os_arch]
      os_arch ||= (mci_name =~ /(i[3|6]86|x64|x86_64|amd64)/i) ? $1 : ""
      hypervisor = opts[:hypervisor]
      hypervisor ||= (mci_name =~ /(xenserver|xen|vmware|esxi|kvm)/i) ? $1 : ""
      image_version = opts[:image_version]
      image_version ||= (mci_name =~ /v(\d+\.\d+)/) ? $1 : ""
      rightlink_version = opts[:rightlink_version]

      description = ""
      description << " #{os}" if os
      description << " #{os_version}" if os_version
      description << " #{hypervisor}" if !hypervisor.empty? && !is_ec2
      if os_arch
        if os_arch =~ /i[3|6]86/
          description << " with 32-bit architecture (#{os_arch})"
        else
          description << " with 64-bit architecture (#{os_arch})"
        end
      end
      description << " for ServerTemplate v#{image_version}" if image_version
      description << " with RightLink #{rightlink_version}" if rightlink_version
      description << "."
      description.strip!
      description
    end

    # Adds an image to an mci, if the image is not already attached to the mci
    #
    # === Parameters
    # image_id(String) - rightscale id of the image to add, which will equal
    #                    the ami-id for amazon and the resource_uid for other clouds
    # cloud_id(Number) - rightscale if of the cloud
    # mci_name(String) - name of the mci to add this image to
    # mci_id(String)   - or (optionally) the rightscale id to add this image to
    # instance_type    - default instance type of the image, if not supplied
    #                    can usually guess
    #
    # === Return
    # mci(MultiCloudImageCloudSettingInternal):: new or existing MCI setting
    def add_image_to_mci(options)
      cloud_id = options[:cloud_id].to_i
      image_id = options[:image_id].to_s
      mci_name = options[:name] || options[:mci_name]
      mci_id   = options[:mci_id] || options[:id]
      rightlink_version = options[:rightlink_version]
      description = options[:description]

      raise ArgumentError, ":cloud_id not supplied" unless cloud_id > 0
      raise ArgumentError, ":image_id not supplied" unless image_id =~ /./
      raise ArgumentError, "MCI name (:name) or id (:mci_id) not supplied" unless (mci_name =~ /./ || mci_id.to_s =~ /^\d+$/)
      raise ArgumentError, "MCI (:mci_id) supplied but an integer" if mci_id and mci_id.to_s !~ /^\d+$/

      if api_version(cloud_id) == "1.0"
        image_id = image_id.split("/").last
        unless image_id =~ /^ami-[0-9a-z]+$/
          raise ArgumentError, "image_id #{image_id} doesn't look like an amazon ami"
        end
      end

      mci = find_mci_by_id(cloud_id, mci_id) if mci_id
      mci = find_mci(cloud_id, mci_name) unless mci
      #validate_mci_name(mci_name) unless mci
      mci = create_mci(cloud_id, mci_name, description, options) unless mci
      mci_setting = find_or_create_cloud_setting(mci, image_id, cloud_id, options)

      add_mci_tags(mci, rightlink_version)

      return mci.href
    end

    def validate_mci_name(name)
    end

    def find_cloud_setting(mci,cloud_id)
      mci.multi_cloud_image_cloud_settings.find { |s| s.cloud_id.to_i == cloud_id.to_i }
    end

    def guess_default_instance_type(cloud_id)
      if api_version(cloud_id) == "1.0"
        return "m1.small"
      else
        names = ["small instance", "1gb server", "nano-h-5", "standard.small", "small", "standard", "n1-standard-1-d", "m1.small", "s2", "1g", "1gb standard instance", "RightScale XS CCI"]
        types = McInstanceType.find_all(cloud_id)
        type = types.find { |t| names.include? t.name.downcase }
        raise "Could not guess default instance type for cloud #{cloud_id}" unless type
        return type.href
      end
    end

    def find_or_create_cloud_setting(mci, image_id, cloud_id, options = {})
      #      debugger
      mci_setting = find_cloud_setting(mci, cloud_id)
      instance_type = options[:instance_type] || guess_default_instance_type(cloud_id)

      if mci_setting
        unless setting_exists?(mci_setting, image_id, cloud_id)
          @logger.warn("Replacing image for cloud #{cloud_id} for MCI #{mci.rs_id}")
          dummy_setting = nil
          if mci.multi_cloud_image_cloud_settings.length <= 1
            dummy_setting = create_dummy_setting(mci, cloud_id)
            # Weird bug workaround, returns the wrong href on create
            dummy_setting.params["href"].sub!("multi_cloud_image_ec2_cloud_settings","multi_cloud_image_cloud_settings")
          end
          res = mci_setting.destroy
          if res.code.to_s !~ /^2\d\d$/
            raise "Non success code returned #{res.inspect} " 
          end
          mci_setting = create_cloud_setting(mci, image_id, cloud_id, instance_type)
          destroy_dummy_setting(dummy_setting) if dummy_setting
        end
      else
        @logger.info("Adding cloud images to MCI #{mci.href}")
        mci_setting = create_cloud_setting(mci, image_id, cloud_id, instance_type)
        #returns nil
      end
      mci_setting
    end

    def setting_exists?(mci_setting, image_id, cloud_id)
      if api_version(cloud_id) == "1.0"
        return mci_setting.image_href.include?(image_id)
      else
        image = McImage.find_all(cloud_id.to_i).find { |img| img.resource_uid.to_s == image_id.to_s }
        raise "No image found for cloud #{cloud_id} with id #{image_id}" unless image
        return mci_setting.image == image.href
      end
    end

    # Create dummy/destroy dummy settings get around a bug in which we have to replace
    # the (lone) setting for an MCI but can't delete it since its the last one left
    # So temporarily add a dummy image to get around the check, then delete it right
    # after
    def create_dummy_setting(mci, cloud_id)
      dummy_cloud_id = cloud_id.to_i == 1 ? 2 : 1
      dummy_image_id = dummy_cloud_id == 1 ? "ami-41814f28" : "ami-f45beff5"
      create_cloud_setting(mci, dummy_image_id, dummy_cloud_id, "m1.small")
    end

    def destroy_dummy_setting(setting)
      @logger.info("Destroying dummy setting #{setting.inspect}")
      setting.destroy
    end

    def create_cloud_setting(mci, image_id, cloud_id, instance_type)
      mci_setting = nil
      if api_version(cloud_id) == "1.0"
        # create the setting
        image_href = "#{@api_url}/ec2_images/#{image_id}?cloud_id=#{cloud_id}"
        mci_setting = MultiCloudImageCloudSettingInternal.create({
        :multi_cloud_image_href  => mci.href,
        :cloud_id                => cloud_id.to_i,
        :ec2_image_href          => image_href, 
        :aws_instance_type       => instance_type})
      else 
        image = McImage.find_all(cloud_id.to_i).find { |img| img.resource_uid.to_s == image_id.to_s }
        raise "No image found for cloud #{cloud_id} with id #{image_id}" unless image
        @logger.debug("Found image id #{image_id} with href #{image.href}")
        mci_id = mci.href.split("/").last
        #        debugger
        mci_setting = McMultiCloudImageSetting.create(mci_id,
                                                      :cloud_href => "/api/clouds/#{cloud_id}",
        :image_href => image.href,
          :instance_type_href => instance_type)
      end
      mci_setting
    end

    # return MultiCloudImageInternal, or nil
    def find_mci_by_id(cloud_id, mci_id)
      existing_mci = MultiCloudImage.find(mci_id.to_i)
      existing_mci.find_and_flatten_settings
      raise ArgumentError, "Could not find #{existing_mci.rs_id}" unless existing_mci
      @logger.info("Using mci #{existing_mci.rs_id} named #{existing_mci.name}")
      existing_mci
    end

    def find_mci(cloud_id, mci_name)
      mcis = MultiCloudImage.find_all.
        select {|n| n.is_head_version && n.name == mci_name }
      mci_ids = mcis.map { |m| m.rs_id }
      @logger.warn("Found multiple MCIs with name #{mci_name}: #{mci_ids.join(', ')}") if mcis.length > 1
      if mcis.length > 0
        existing_mci = mcis.first
        existing_mci.find_and_flatten_settings
        @logger.info("Found mci #{existing_mci.rs_id}") if existing_mci
        return existing_mci
      else
        return nil
      end
    end

    def create_mci(cloud_id, mci_name, description, opts = {})
      description ||= default_description(mci_name, api_version(cloud_id) == "1.0", opts)
      @logger.info("Creating mci \"#{mci_name}\" with description: \"#{description}\"")

      mci = MultiCloudImageInternal.create({:name => mci_name, :description => description})

      raise "Could not create MCI" unless mci
      mci = MultiCloudImage.find(mci.rs_id.to_i)
      mci.find_and_flatten_settings
      return mci
    end

    def add_mci_tags(mci, rightlink_version)
      tags = ["provides:rs_agent_type=right_link"]
      if !rightlink_version.to_s.empty?
        tags << "provides:rs_agent_version=#{rightlink_version}"
      end
      add_tags_to_href(mci.href, tags, "1.0")
    end

    # mci(MultiCloudImageInternal):: the MCI to add the tag to
    # Tag an mci or raise an error on failure
    def add_tags_to_href(href, tags, api_version)
      @logger.info "Adding tags #{tags.inspect} to #{href}"
      begin
        if api_version == "1.0"
          result = Tag.set(href, tags)
        else
          result = McTag.set(href, tags)
        end
        @logger.debug("Successfully tagged MCI. Code: #{result.code}")
      rescue Exception => e
        @logger.error("Failed to tag href #{href}! #{e.inspect}")
        raise e
      end 
    end

    def api_version(cloud_id)
      cloud_id.to_i < 50 ? "1.0" : "1.5"
    end

  end
end
