#define UTS_RELEASE "2.6.32-313-ec2"
